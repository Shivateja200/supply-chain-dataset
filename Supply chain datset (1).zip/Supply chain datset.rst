.. code:: ipython3

    import pandas as pd
    import numpy as np

.. code:: ipython3

    import zipfile
    import os
    # Now, we have to unzip it
    with zipfile.ZipFile('datacosupplychainDataset.csv.zip', 'r') as zip_ref:
        zip_ref.extractall('Supply_chain_data')
    print(os.listdir('Supply_chain_data'))


.. parsed-literal::

    ['DataCoSupplyChainDataset.csv']
    

.. code:: ipython3

    # Our encoding needs to be change, so we change it to 'latin1' encoding to read the CSV file
    file_path = 'Supply_chain_data/DataCoSupplyChainDataset.csv'  # Adjust file name if necessary
    data = pd.read_csv(file_path, encoding='latin1')
    
    data.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Type</th>
          <th>Days for shipping (real)</th>
          <th>Days for shipment (scheduled)</th>
          <th>Benefit per order</th>
          <th>Sales per customer</th>
          <th>Delivery Status</th>
          <th>Late_delivery_risk</th>
          <th>Category Id</th>
          <th>Category Name</th>
          <th>Customer City</th>
          <th>...</th>
          <th>Order Zipcode</th>
          <th>Product Card Id</th>
          <th>Product Category Id</th>
          <th>Product Description</th>
          <th>Product Image</th>
          <th>Product Name</th>
          <th>Product Price</th>
          <th>Product Status</th>
          <th>shipping date (DateOrders)</th>
          <th>Shipping Mode</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>DEBIT</td>
          <td>3</td>
          <td>4</td>
          <td>91.250000</td>
          <td>314.640015</td>
          <td>Advance shipping</td>
          <td>0</td>
          <td>73</td>
          <td>Sporting Goods</td>
          <td>Caguas</td>
          <td>...</td>
          <td>NaN</td>
          <td>1360</td>
          <td>73</td>
          <td>NaN</td>
          <td>http://images.acmesports.sports/Smart+watch</td>
          <td>Smart watch</td>
          <td>327.75</td>
          <td>0</td>
          <td>2/3/2018 22:56</td>
          <td>Standard Class</td>
        </tr>
        <tr>
          <th>1</th>
          <td>TRANSFER</td>
          <td>5</td>
          <td>4</td>
          <td>-249.089996</td>
          <td>311.359985</td>
          <td>Late delivery</td>
          <td>1</td>
          <td>73</td>
          <td>Sporting Goods</td>
          <td>Caguas</td>
          <td>...</td>
          <td>NaN</td>
          <td>1360</td>
          <td>73</td>
          <td>NaN</td>
          <td>http://images.acmesports.sports/Smart+watch</td>
          <td>Smart watch</td>
          <td>327.75</td>
          <td>0</td>
          <td>1/18/2018 12:27</td>
          <td>Standard Class</td>
        </tr>
        <tr>
          <th>2</th>
          <td>CASH</td>
          <td>4</td>
          <td>4</td>
          <td>-247.779999</td>
          <td>309.720001</td>
          <td>Shipping on time</td>
          <td>0</td>
          <td>73</td>
          <td>Sporting Goods</td>
          <td>San Jose</td>
          <td>...</td>
          <td>NaN</td>
          <td>1360</td>
          <td>73</td>
          <td>NaN</td>
          <td>http://images.acmesports.sports/Smart+watch</td>
          <td>Smart watch</td>
          <td>327.75</td>
          <td>0</td>
          <td>1/17/2018 12:06</td>
          <td>Standard Class</td>
        </tr>
        <tr>
          <th>3</th>
          <td>DEBIT</td>
          <td>3</td>
          <td>4</td>
          <td>22.860001</td>
          <td>304.809998</td>
          <td>Advance shipping</td>
          <td>0</td>
          <td>73</td>
          <td>Sporting Goods</td>
          <td>Los Angeles</td>
          <td>...</td>
          <td>NaN</td>
          <td>1360</td>
          <td>73</td>
          <td>NaN</td>
          <td>http://images.acmesports.sports/Smart+watch</td>
          <td>Smart watch</td>
          <td>327.75</td>
          <td>0</td>
          <td>1/16/2018 11:45</td>
          <td>Standard Class</td>
        </tr>
        <tr>
          <th>4</th>
          <td>PAYMENT</td>
          <td>2</td>
          <td>4</td>
          <td>134.210007</td>
          <td>298.250000</td>
          <td>Advance shipping</td>
          <td>0</td>
          <td>73</td>
          <td>Sporting Goods</td>
          <td>Caguas</td>
          <td>...</td>
          <td>NaN</td>
          <td>1360</td>
          <td>73</td>
          <td>NaN</td>
          <td>http://images.acmesports.sports/Smart+watch</td>
          <td>Smart watch</td>
          <td>327.75</td>
          <td>0</td>
          <td>1/15/2018 11:24</td>
          <td>Standard Class</td>
        </tr>
      </tbody>
    </table>
    <p>5 rows × 53 columns</p>
    </div>



.. code:: ipython3

    data.info()
    data.describe()
    data.isnull().sum()
    


.. parsed-literal::

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 180519 entries, 0 to 180518
    Data columns (total 53 columns):
     #   Column                         Non-Null Count   Dtype  
    ---  ------                         --------------   -----  
     0   Type                           180519 non-null  object 
     1   Days for shipping (real)       180519 non-null  int64  
     2   Days for shipment (scheduled)  180519 non-null  int64  
     3   Benefit per order              180519 non-null  float64
     4   Sales per customer             180519 non-null  float64
     5   Delivery Status                180519 non-null  object 
     6   Late_delivery_risk             180519 non-null  int64  
     7   Category Id                    180519 non-null  int64  
     8   Category Name                  180519 non-null  object 
     9   Customer City                  180519 non-null  object 
     10  Customer Country               180519 non-null  object 
     11  Customer Email                 180519 non-null  object 
     12  Customer Fname                 180519 non-null  object 
     13  Customer Id                    180519 non-null  int64  
     14  Customer Lname                 180511 non-null  object 
     15  Customer Password              180519 non-null  object 
     16  Customer Segment               180519 non-null  object 
     17  Customer State                 180519 non-null  object 
     18  Customer Street                180519 non-null  object 
     19  Customer Zipcode               180516 non-null  float64
     20  Department Id                  180519 non-null  int64  
     21  Department Name                180519 non-null  object 
     22  Latitude                       180519 non-null  float64
     23  Longitude                      180519 non-null  float64
     24  Market                         180519 non-null  object 
     25  Order City                     180519 non-null  object 
     26  Order Country                  180519 non-null  object 
     27  Order Customer Id              180519 non-null  int64  
     28  order date (DateOrders)        180519 non-null  object 
     29  Order Id                       180519 non-null  int64  
     30  Order Item Cardprod Id         180519 non-null  int64  
     31  Order Item Discount            180519 non-null  float64
     32  Order Item Discount Rate       180519 non-null  float64
     33  Order Item Id                  180519 non-null  int64  
     34  Order Item Product Price       180519 non-null  float64
     35  Order Item Profit Ratio        180519 non-null  float64
     36  Order Item Quantity            180519 non-null  int64  
     37  Sales                          180519 non-null  float64
     38  Order Item Total               180519 non-null  float64
     39  Order Profit Per Order         180519 non-null  float64
     40  Order Region                   180519 non-null  object 
     41  Order State                    180519 non-null  object 
     42  Order Status                   180519 non-null  object 
     43  Order Zipcode                  24840 non-null   float64
     44  Product Card Id                180519 non-null  int64  
     45  Product Category Id            180519 non-null  int64  
     46  Product Description            0 non-null       float64
     47  Product Image                  180519 non-null  object 
     48  Product Name                   180519 non-null  object 
     49  Product Price                  180519 non-null  float64
     50  Product Status                 180519 non-null  int64  
     51  shipping date (DateOrders)     180519 non-null  object 
     52  Shipping Mode                  180519 non-null  object 
    dtypes: float64(15), int64(14), object(24)
    memory usage: 73.0+ MB
    



.. parsed-literal::

    Type                                  0
    Days for shipping (real)              0
    Days for shipment (scheduled)         0
    Benefit per order                     0
    Sales per customer                    0
    Delivery Status                       0
    Late_delivery_risk                    0
    Category Id                           0
    Category Name                         0
    Customer City                         0
    Customer Country                      0
    Customer Email                        0
    Customer Fname                        0
    Customer Id                           0
    Customer Lname                        8
    Customer Password                     0
    Customer Segment                      0
    Customer State                        0
    Customer Street                       0
    Customer Zipcode                      3
    Department Id                         0
    Department Name                       0
    Latitude                              0
    Longitude                             0
    Market                                0
    Order City                            0
    Order Country                         0
    Order Customer Id                     0
    order date (DateOrders)               0
    Order Id                              0
    Order Item Cardprod Id                0
    Order Item Discount                   0
    Order Item Discount Rate              0
    Order Item Id                         0
    Order Item Product Price              0
    Order Item Profit Ratio               0
    Order Item Quantity                   0
    Sales                                 0
    Order Item Total                      0
    Order Profit Per Order                0
    Order Region                          0
    Order State                           0
    Order Status                          0
    Order Zipcode                    155679
    Product Card Id                       0
    Product Category Id                   0
    Product Description              180519
    Product Image                         0
    Product Name                          0
    Product Price                         0
    Product Status                        0
    shipping date (DateOrders)            0
    Shipping Mode                         0
    dtype: int64



.. code:: ipython3

    # Checking missing values
    missing_values = data.isnull().sum()
    print(missing_values[missing_values > 0])
    
    # Drop 'Product Description' as it is completely empty
    data = data.drop(columns=['Product Description'])
    
    # Handle other missing values, unkown instead of null
    data['Customer Lname'] = data['Customer Lname'].fillna('Unknown')
    data['Customer Zipcode'] = data['Customer Zipcode'].fillna('Unknown')
    data['Order Zipcode'] = data['Order Zipcode'].fillna('Unknown')
    


.. parsed-literal::

    Customer Lname              8
    Customer Zipcode            3
    Order Zipcode          155679
    Product Description    180519
    dtype: int64
    

.. code:: ipython3

    # Change fomat of some clumns date columns to datetime
    data['order date (DateOrders)'] = pd.to_datetime(data['order date (DateOrders)'], format='%m/%d/%Y %H:%M')
    data['shipping date (DateOrders)'] = pd.to_datetime(data['shipping date (DateOrders)'], format='%m/%d/%Y %H:%M')

.. code:: ipython3

    file_path = 'C:\Users\shiva\Downloads\DataCoSupplyChainDataset.csv'
    data.to_csv(file_path, index=False)
    print(f"Dataset saved successfully as '{file_path}'")


::


      Cell In[24], line 1
        file_path = 'C:\Users\shiva\Downloads\DataCoSupplyChainDataset.csv'
                    ^
    SyntaxError: (unicode error) 'unicodeescape' codec can't decode bytes in position 2-3: truncated \UXXXXXXXX escape
    


.. code:: ipython3

    # Summary statistics
    print(data.describe())


.. parsed-literal::

           Days for shipping (real)  Days for shipment (scheduled)  \
    count             180519.000000                  180519.000000   
    mean                   3.497654                       2.931847   
    min                    0.000000                       0.000000   
    25%                    2.000000                       2.000000   
    50%                    3.000000                       4.000000   
    75%                    5.000000                       4.000000   
    max                    6.000000                       4.000000   
    std                    1.623722                       1.374449   
    
           Benefit per order  Sales per customer  Late_delivery_risk  \
    count      180519.000000       180519.000000       180519.000000   
    mean           21.974989          183.107609            0.548291   
    min         -4274.979980            7.490000            0.000000   
    25%             7.000000          104.379997            0.000000   
    50%            31.520000          163.990005            1.000000   
    75%            64.800003          247.399994            1.000000   
    max           911.799988         1939.989990            1.000000   
    std           104.433526          120.043670            0.497664   
    
             Category Id    Customer Id  Department Id       Latitude  \
    count  180519.000000  180519.000000  180519.000000  180519.000000   
    mean       31.851451    6691.379495       5.443460      29.719955   
    min         2.000000       1.000000       2.000000     -33.937553   
    25%        18.000000    3258.500000       4.000000      18.265432   
    50%        29.000000    6457.000000       5.000000      33.144863   
    75%        45.000000    9779.000000       7.000000      39.279617   
    max        76.000000   20757.000000      12.000000      48.781933   
    std        15.640064    4162.918106       1.629246       9.813646   
    
               Longitude  ...  Order Item Profit Ratio Order Item Quantity  \
    count  180519.000000  ...            180519.000000       180519.000000   
    mean      -84.915675  ...                 0.120647            2.127638   
    min      -158.025986  ...                -2.750000            1.000000   
    25%       -98.446312  ...                 0.080000            1.000000   
    50%       -76.847908  ...                 0.270000            1.000000   
    75%       -66.370583  ...                 0.360000            3.000000   
    max       115.263077  ...                 0.500000            5.000000   
    std        21.433241  ...                 0.466796            1.453451   
    
                   Sales  Order Item Total  Order Profit Per Order  \
    count  180519.000000     180519.000000           180519.000000   
    mean      203.772096        183.107609               21.974989   
    min         9.990000          7.490000            -4274.979980   
    25%       119.980003        104.379997                7.000000   
    50%       199.919998        163.990005               31.520000   
    75%       299.950012        247.399994               64.800003   
    max      1999.989990       1939.989990              911.799988   
    std       132.273077        120.043670              104.433526   
    
           Product Card Id  Product Category Id  Product Price  Product Status  \
    count    180519.000000        180519.000000  180519.000000        180519.0   
    mean        692.509764            31.851451     141.232550             0.0   
    min          19.000000             2.000000       9.990000             0.0   
    25%         403.000000            18.000000      50.000000             0.0   
    50%         627.000000            29.000000      59.990002             0.0   
    75%        1004.000000            45.000000     199.990005             0.0   
    max        1363.000000            76.000000    1999.989990             0.0   
    std         336.446807            15.640064     139.732492             0.0   
    
              shipping date (DateOrders)  
    count                         180519  
    mean   2016-06-16 05:45:23.202433024  
    min              2015-01-03 00:00:00  
    25%              2015-09-25 06:59:00  
    50%              2016-06-15 08:32:00  
    75%              2017-03-04 21:29:00  
    max              2018-02-06 22:14:00  
    std                              NaN  
    
    [8 rows x 28 columns]
    

.. code:: ipython3

    import matplotlib.pyplot as plt
    import seaborn as sns
    
    # Distribution of Sales
    plt.figure(figsize=(10, 6))
    sns.histplot(data['Sales'], bins=30, kde=True)
    plt.title('Distribution of Sales')
    plt.xlabel('Sales')
    plt.ylabel('Frequency')
    plt.show()



.. image:: output_8_0.png


.. code:: ipython3

    # Scatter plot between Sales and Benefit per order
    plt.figure(figsize=(10, 6))
    sns.scatterplot(x='Sales', y='Benefit per order', data=data)
    plt.title('Sales vs Benefit per Order')
    plt.xlabel('Sales')
    plt.ylabel('Benefit per Order')
    plt.show()



.. image:: output_9_0.png


.. code:: ipython3

    # Count plot of Late Delivery Risk by Shipping Mode
    plt.figure(figsize=(12, 8))
    sns.countplot(x='Late_delivery_risk', hue='Shipping Mode', data=data)
    plt.title('Late Delivery Risk by Shipping Mode')
    plt.xlabel('Late Delivery Risk')
    plt.ylabel('Count')
    plt.legend(title='Shipping Mode')
    plt.show()
    



.. image:: output_10_0.png


.. code:: ipython3

    print(data['Delivery Status'].value_counts())


.. parsed-literal::

    Delivery Status
    Late delivery        98977
    Advance shipping     41592
    Shipping on time     32196
    Shipping canceled     7754
    Name: count, dtype: int64
    

.. code:: ipython3

    def generate_delivered_date(row):
        shipping_date = row['shipping date (DateOrders)']
        shipping_mode = row['Shipping Mode']
    
        # Initialize delivered date as NaN
        delivered_date = np.nan
    
        # Set delivered date only if delivery status is "Shipping on time"
        if row['Delivery Status'] == 'Shipping on time':
            if shipping_mode == 'Standard Class':
                delivered_date = shipping_date + pd.Timedelta(days=np.random.randint(1, 10))
            elif shipping_mode == 'Second Class':
                delivered_date = shipping_date + pd.Timedelta(days=np.random.randint(1, 5))
            elif shipping_mode == 'Same Day':
                delivered_date = shipping_date + pd.Timedelta(hours=np.random.randint(1, 12))
            elif shipping_mode == 'First Class':  # Assuming First Class is also a mode
                delivered_date = shipping_date + pd.Timedelta(days=np.random.randint(1, 3))
    
        return delivered_date
    
    # Apply the function row-wise to generate delivered dates
    data['Delivered Date'] = data.apply(generate_delivered_date, axis=1)
    
    # Display the updated DataFrame
    print(data)


.. parsed-literal::

                Type  Days for shipping (real)  Days for shipment (scheduled)  \
    0          DEBIT                         3                              4   
    1       TRANSFER                         5                              4   
    2           CASH                         4                              4   
    3          DEBIT                         3                              4   
    4        PAYMENT                         2                              4   
    ...          ...                       ...                            ...   
    180514      CASH                         4                              4   
    180515     DEBIT                         3                              2   
    180516  TRANSFER                         5                              4   
    180517   PAYMENT                         3                              4   
    180518   PAYMENT                         4                              4   
    
            Benefit per order  Sales per customer   Delivery Status  \
    0               91.250000          314.640015  Advance shipping   
    1             -249.089996          311.359985     Late delivery   
    2             -247.779999          309.720001  Shipping on time   
    3               22.860001          304.809998  Advance shipping   
    4              134.210007          298.250000  Advance shipping   
    ...                   ...                 ...               ...   
    180514          40.000000          399.980011  Shipping on time   
    180515        -613.770019          395.980011     Late delivery   
    180516         141.110001          391.980011     Late delivery   
    180517         186.229996          387.980011  Advance shipping   
    180518         168.949997          383.980011  Shipping on time   
    
            Late_delivery_risk  Category Id   Category Name Customer City  ...  \
    0                        0           73  Sporting Goods        Caguas  ...   
    1                        1           73  Sporting Goods        Caguas  ...   
    2                        0           73  Sporting Goods      San Jose  ...   
    3                        0           73  Sporting Goods   Los Angeles  ...   
    4                        0           73  Sporting Goods        Caguas  ...   
    ...                    ...          ...             ...           ...  ...   
    180514                   0           45         Fishing      Brooklyn  ...   
    180515                   1           45         Fishing   Bakersfield  ...   
    180516                   1           45         Fishing       Bristol  ...   
    180517                   0           45         Fishing        Caguas  ...   
    180518                   0           45         Fishing        Caguas  ...   
    
           Order Zipcode Product Card Id Product Category Id  \
    0            Unknown            1360                  73   
    1            Unknown            1360                  73   
    2            Unknown            1360                  73   
    3            Unknown            1360                  73   
    4            Unknown            1360                  73   
    ...              ...             ...                 ...   
    180514       Unknown            1004                  45   
    180515       Unknown            1004                  45   
    180516       Unknown            1004                  45   
    180517       Unknown            1004                  45   
    180518       Unknown            1004                  45   
    
                                                Product Image  \
    0            http://images.acmesports.sports/Smart+watch    
    1            http://images.acmesports.sports/Smart+watch    
    2            http://images.acmesports.sports/Smart+watch    
    3            http://images.acmesports.sports/Smart+watch    
    4            http://images.acmesports.sports/Smart+watch    
    ...                                                   ...   
    180514  http://images.acmesports.sports/Field+%26+Stre...   
    180515  http://images.acmesports.sports/Field+%26+Stre...   
    180516  http://images.acmesports.sports/Field+%26+Stre...   
    180517  http://images.acmesports.sports/Field+%26+Stre...   
    180518  http://images.acmesports.sports/Field+%26+Stre...   
    
                                         Product Name Product Price  \
    0                                    Smart watch     327.750000   
    1                                    Smart watch     327.750000   
    2                                    Smart watch     327.750000   
    3                                    Smart watch     327.750000   
    4                                    Smart watch     327.750000   
    ...                                           ...           ...   
    180514  Field & Stream Sportsman 16 Gun Fire Safe    399.980011   
    180515  Field & Stream Sportsman 16 Gun Fire Safe    399.980011   
    180516  Field & Stream Sportsman 16 Gun Fire Safe    399.980011   
    180517  Field & Stream Sportsman 16 Gun Fire Safe    399.980011   
    180518  Field & Stream Sportsman 16 Gun Fire Safe    399.980011   
    
           Product Status shipping date (DateOrders)   Shipping Mode  \
    0                   0        2018-02-03 22:56:00  Standard Class   
    1                   0        2018-01-18 12:27:00  Standard Class   
    2                   0        2018-01-17 12:06:00  Standard Class   
    3                   0        2018-01-16 11:45:00  Standard Class   
    4                   0        2018-01-15 11:24:00  Standard Class   
    ...               ...                        ...             ...   
    180514              0        2016-01-20 03:40:00  Standard Class   
    180515              0        2016-01-19 01:34:00    Second Class   
    180516              0        2016-01-20 21:00:00  Standard Class   
    180517              0        2016-01-18 20:18:00  Standard Class   
    180518              0        2016-01-19 18:54:00  Standard Class   
    
                Delivered Date  
    0                      NaT  
    1                      NaT  
    2      2018-01-21 12:06:00  
    3                      NaT  
    4                      NaT  
    ...                    ...  
    180514 2016-01-26 03:40:00  
    180515                 NaT  
    180516                 NaT  
    180517                 NaT  
    180518 2016-01-26 18:54:00  
    
    [180519 rows x 53 columns]
    

.. code:: ipython3

    print(data['Delivered Date'].value_counts())


.. parsed-literal::

    Delivered Date
    2016-01-19 17:41:00    5
    2015-03-24 02:52:00    5
    2015-09-04 00:42:00    5
    2015-09-04 14:12:00    5
    2015-02-06 01:42:00    5
                          ..
    2016-02-18 13:58:00    1
    2015-06-07 13:27:00    1
    2017-04-21 21:05:00    1
    2015-06-11 01:43:00    1
    2016-01-26 18:54:00    1
    Name: count, Length: 26994, dtype: int64
    

.. code:: ipython3

    import pandas as pd
    from sklearn.model_selection import train_test_split
    from sklearn.tree import DecisionTreeClassifier
    from sklearn.metrics import accuracy_score, classification_report
    
    # Assuming 'data' is my DataFrame with the required columns
    # Feature selection
    X = data[['Days for shipping (real)', 'Days for shipment (scheduled)', 'Late_delivery_risk']]
    y = data['Delivery Status']
    
    # Split data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Initialize decision tree classifier
    clf = DecisionTreeClassifier(random_state=42)
    
    # Train the model
    clf.fit(X_train, y_train)
    
    # Predict on test data
    y_pred = clf.predict(X_test)
    
    # Evaluate model performance
    accuracy = accuracy_score(y_test, y_pred)
    print(f"Accuracy: {accuracy:.2f}")
    
    # Classification report
    print(classification_report(y_test, y_pred))
    


.. parsed-literal::

    Accuracy: 0.98
                       precision    recall  f1-score   support
    
     Advance shipping       0.96      1.00      0.98      8282
        Late delivery       1.00      1.00      1.00     19797
    Shipping canceled       1.00      0.58      0.74      1558
     Shipping on time       0.95      1.00      0.98      6467
    
             accuracy                           0.98     36104
            macro avg       0.98      0.90      0.92     36104
         weighted avg       0.98      0.98      0.98     36104
    
    

.. code:: ipython3

    from sklearn.linear_model import LinearRegression
    from sklearn.metrics import mean_squared_error
    
    # Feature selection
    X = data[['Days for shipping (real)', 'Days for shipment (scheduled)', 'Late_delivery_risk']]
    y = data['Sales']
    
    # Split data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Initialize linear regression model
    model = LinearRegression()
    
    # Train the model
    model.fit(X_train, y_train)
    
    # Predict on test data
    y_pred = model.predict(X_test)
    
    # Evaluate model performance
    mse = mean_squared_error(y_test, y_pred)
    print(f"Mean Squared Error: {mse:.2f}")
    


.. parsed-literal::

    Mean Squared Error: 17341.34
    

.. code:: ipython3

    from sklearn.linear_model import LogisticRegression
    
    X = data[['Days for shipping (real)', 'Days for shipment (scheduled)', 'Late_delivery_risk']]
    y = (data['Delivery Status'] == 'Shipping on time').astype(int)  # Convert to binary label
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    
    log_reg = LogisticRegression()
    
    log_reg.fit(X_train, y_train)
    
    
    y_pred = log_reg.predict(X_test)
    
    
    accuracy = accuracy_score(y_test, y_pred)
    print(f"Accuracy: {accuracy:.2f}")
    
    
    print(classification_report(y_test, y_pred))
    


.. parsed-literal::

    Accuracy: 0.97
                  precision    recall  f1-score   support
    
               0       1.00      0.96      0.98     29637
               1       0.84      1.00      0.91      6467
    
        accuracy                           0.97     36104
       macro avg       0.92      0.98      0.95     36104
    weighted avg       0.97      0.97      0.97     36104
    
    

